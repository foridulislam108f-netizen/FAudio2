package com.faudio.player

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.util.Base64
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.webkit.WebViewAssetLoader
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.MediaPlayer
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // ---------- ExoPlayer engine ----------
    private var exo: ExoPlayer? = null
    private var gen = 0
    private var lastReason = 1
    private var lastErr = ""
    private val ui = Handler(Looper.getMainLooper())

    // Broad-format native engine for files WebView/platform codecs cannot decode.
    private var vlc: LibVLC? = null
    private var vlcPlayer: MediaPlayer? = null
    private var vlcGeneration = 0
    private var vlcPlaying = false
    private var vlcEnded = false
    private var vlcRepeat = false
    private var vlcDuration = -1L

    private val ticker = object : Runnable {
        override fun run() {
            val p = exo ?: return
            pushState("tick")
            if (p.playWhenReady && p.playbackState != Player.STATE_ENDED && p.playbackState != Player.STATE_IDLE) {
                ui.postDelayed(this, 500)
            }
        }
    }

    private fun startTicker() {
        ui.removeCallbacks(ticker)
        ui.postDelayed(ticker, 500)
    }

    private fun pushState(kind: String) {
        val p = exo ?: return
        try {
            val dur = if (p.duration == C.TIME_UNSET) -1.0 else p.duration / 1000.0
            val o = JSONObject()
            o.put("k", kind)
            o.put("gen", gen)
            o.put("pos", p.currentPosition / 1000.0)
            o.put("dur", dur)
            o.put("wwr", p.playWhenReady)
            o.put("st", p.playbackState)
            o.put("why", lastReason)
            o.put("err", lastErr)
            webView.evaluateJavascript("window.__exo&&window.__exo(" + o.toString() + ")", null)
        } catch (_: Exception) {
        }
    }

    private fun pushVlcState(kind: String, error: String = "") {
        val p = vlcPlayer ?: return
        try {
            val o = JSONObject()
            o.put("k", kind)
            o.put("gen", vlcGeneration)
            o.put("pos", p.time.coerceAtLeast(0L) / 1000.0)
            val duration = p.length.takeIf { it > 0 } ?: vlcDuration
            o.put("dur", if (duration > 0) duration / 1000.0 else -1.0)
            o.put("wwr", vlcPlaying)
            o.put("st", if (vlcEnded) 4 else if (vlcPlaying) 3 else 2)
            o.put("why", lastReason)
            o.put("err", error)
            webView.evaluateJavascript("window.__exo&&window.__exo(" + o.toString() + ")", null)
        } catch (_: Exception) {}
    }

    private fun ensureVlc(): MediaPlayer {
        vlcPlayer?.let { return it }
        val engine = LibVLC(this, arrayListOf(
            "--audio-time-stretch", "--file-caching=300",
            "--network-caching=1000", "--no-video-title-show"
        ))
        val player = MediaPlayer(engine)
        player.setEventListener { event ->
            runOnUiThread {
                when (event.type) {
                    MediaPlayer.Event.Playing -> { vlcPlaying = true; vlcEnded = false; pushVlcState("playing") }
                    MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> { vlcPlaying = false; pushVlcState("pause") }
                    MediaPlayer.Event.EndReached -> if (vlcRepeat) player.play() else {
                        vlcPlaying = false; vlcEnded = true; pushVlcState("ended")
                    }
                    MediaPlayer.Event.TimeChanged, MediaPlayer.Event.LengthChanged -> pushVlcState("tick")
                    MediaPlayer.Event.EncounteredError -> { vlcPlaying = false; pushVlcState("error", "VLC_DECODE_FAILED") }
                }
            }
        }
        vlc = engine
        vlcPlayer = player
        return player
    }

    private fun releaseVlc() {
        try { vlcPlayer?.stop() } catch (_: Exception) {}
        try { vlcPlayer?.release() } catch (_: Exception) {}
        try { vlc?.release() } catch (_: Exception) {}
        vlcPlayer = null
        vlc = null
    }

    private fun vlcLoad(uri: Uri, play: Boolean, generation: Int) {
        val p = ensureVlc()
        vlcGeneration = generation
        vlcPlaying = false
        vlcEnded = false
        vlcDuration = -1L
        try {
            p.stop()
            p.play(uri)
            p.setVolume(100)
            p.setRate(1f)
            if (!play) p.pause()
            pushVlcState("load")
        } catch (_: Exception) {
            pushVlcState("error", "VLC_LOAD_FAILED")
        }
    }

    private fun ensureExo(): ExoPlayer {
        exo?.let { return it }
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        val renderers = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            // PREFER: try extension decoders (FFmpeg, etc.) before the platform
            // decoder, so formats like WMA/APE/AC3/ALAC play even on devices
            // whose system codec list is narrow.
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        val extractors = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this, extractors))
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                pushState("st")
                if (playbackState == Player.STATE_READY && p.playWhenReady) startTicker()
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                lastReason = reason
                pushState("wwr")
                if (playWhenReady) startTicker()
            }

            override fun onPlayerError(error: PlaybackException) {
                lastErr = error.errorCodeName
                pushState("error")
            }
        })
        exo = p
        return p
    }

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission() =
        checkSelfPermission(audioPermission) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val wanted = ArrayList<String>()
        if (!hasAudioPermission()) wanted.add(audioPermission)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (wanted.isNotEmpty()) requestPermissions(wanted.toTypedArray(), 1)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        webView.addJavascriptInterface(Bridge(), "NativeAudio")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val path = request.url.path ?: ""
                if (path.startsWith("/media/")) return serveMedia(request)
                return loader.shouldInterceptRequest(request.url)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*", "application/ogg", "application/octet-stream"))
                }
                return try {
                    startActivityForResult(Intent.createChooser(intent, "Select audio"), REQ_FILES)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        }

        startPlayService()
    }

    /** JS <-> Android bridge: lists every audio file on the device. */
    inner class Bridge {
        @JavascriptInterface
        fun hasPermission(): Boolean = hasAudioPermission()

        // ---- Native LibVLC engine (broad container/codec fallback) ----
        @JavascriptInterface
        fun exoAvailable(): Boolean = true

        @JavascriptInterface
        fun exoLoad(id: Long, play: Boolean, g: Int) {
            runOnUiThread {
                try {
                    lastReason = 1
                    lastErr = ""
                    val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    vlcLoad(uri, play, g)
                } catch (e: Exception) {
                    pushVlcState("error", "VLC_LOAD_FAILED")
                }
            }
        }

        @JavascriptInterface
        fun exoPlay() { runOnUiThread { vlcPlayer?.play(); vlcPlaying = true; pushVlcState("playing") } }

        @JavascriptInterface
        fun exoPause() { runOnUiThread { vlcPlayer?.pause(); vlcPlaying = false; pushVlcState("pause") } }

        @JavascriptInterface
        fun exoSeek(ms: Long) { runOnUiThread { vlcPlayer?.setTime(ms); pushVlcState("tick") } }

        @JavascriptInterface
        fun exoStop() {
            runOnUiThread {
                ui.removeCallbacks(ticker)
                vlcPlayer?.stop()
                vlcPlaying = false
                vlcEnded = false
            }
        }

        @JavascriptInterface
        fun exoSpeed(v: Double) { runOnUiThread { vlcPlayer?.setRate(v.toFloat()) } }

        @JavascriptInterface
        fun exoVolume(v: Double) { runOnUiThread { vlcPlayer?.setVolume((v * 100).toInt().coerceIn(0, 100)) } }

        @JavascriptInterface
        fun exoRepeat(on: Boolean) {
            runOnUiThread { vlcRepeat = on }
        }


        // ---- Picked files are streamed to cacheDir, then played by LibVLC ----
        private var cacheOut: FileOutputStream? = null
        private var cacheFile: File? = null

        @JavascriptInterface
        fun cacheBegin(ext: String): Boolean {
            return try {
                cacheOut?.close()
                val dir = File(cacheDir, "play"); dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val safe = ext.filter { it.isLetterOrDigit() }.take(8).ifEmpty { "bin" }
                val f = File(dir, "cur.$safe")
                cacheFile = f
                cacheOut = FileOutputStream(f)
                true
            } catch (e: Exception) { false }
        }

        @JavascriptInterface
        fun cacheChunk(b64: String): Boolean {
            return try { cacheOut?.write(Base64.decode(b64, Base64.DEFAULT)); true } catch (e: Exception) { false }
        }

        @JavascriptInterface
        fun cacheEnd(): String {
            return try { cacheOut?.close(); cacheOut = null; cacheFile?.absolutePath ?: "" } catch (e: Exception) { "" }
        }

        @JavascriptInterface
        fun exoLoadFile(path: String, play: Boolean, g: Int) {
            runOnUiThread {
                try {
                    lastReason = 1
                    lastErr = ""
                    vlcLoad(Uri.fromFile(File(path)), play, g)
                } catch (e: Exception) {
                    lastErr = "LOAD_FAILED"
                    pushVlcState("error", "VLC_LOAD_FAILED")
                }
            }
        }

        // ---- kHz / format / kbps for ANY audio file on the device ----
        @JavascriptInterface
        fun audioInfo(id: Long): String {
            val o = JSONObject()
            val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
            var size = 0L
            try {
                contentResolver.openAssetFileDescriptor(uri, "r")?.use { size = it.length }
            } catch (_: Exception) {}
            var durUs = 0L
            try {
                val ex = MediaExtractor()
                try {
                    ex.setDataSource(this@MainActivity, uri, null)
                    for (i in 0 until ex.trackCount) {
                        val f = ex.getTrackFormat(i)
                        val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                        if (!mime.startsWith("audio/")) continue
                        o.put("mime", mime)
                        if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) o.put("sampleRate", f.getInteger(MediaFormat.KEY_SAMPLE_RATE))
                        if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) o.put("channels", f.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                        if (f.containsKey(MediaFormat.KEY_BIT_RATE)) o.put("bitrate", f.getInteger(MediaFormat.KEY_BIT_RATE) / 1000)
                        if (f.containsKey(MediaFormat.KEY_DURATION)) durUs = f.getLong(MediaFormat.KEY_DURATION)
                        break
                    }
                } finally { ex.release() }
            } catch (_: Exception) {}
            try {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(this@MainActivity, uri)
                    if (!o.has("bitrate") || o.optInt("bitrate") <= 0) {
                        val br = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()
                        if (br != null && br > 0) o.put("bitrate", br / 1000)
                    }
                    if (durUs <= 0) {
                        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                        if (d != null) durUs = d * 1000
                    }
                } finally { r.release() }
            } catch (_: Exception) {}
            // last resort: average bitrate from file size and length
            if ((!o.has("bitrate") || o.optInt("bitrate") <= 0) && size > 0 && durUs > 0) {
                o.put("bitrate", (size * 8.0 / (durUs / 1_000_000.0) / 1000.0).toInt())
            }
            return o.toString()
        }

        @JavascriptInterface
        fun scan(): String {
            val arr = JSONArray()
            if (!hasAudioPermission()) return arr.toString()
            val proj = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.MIME_TYPE,
                MediaStore.Audio.Media.DATE_ADDED
            )
            // Skip system ringtones / notification / alarm sounds; everything else is added.
            val sel = "${MediaStore.Audio.Media.IS_RINGTONE}=0 AND " +
                "${MediaStore.Audio.Media.IS_NOTIFICATION}=0 AND " +
                "${MediaStore.Audio.Media.IS_ALARM}=0 AND ${MediaStore.Audio.Media.SIZE}>0"
            try {
                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null,
                    "${MediaStore.Audio.Media.DISPLAY_NAME} COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val artist = c.getString(2) ?: ""
                        val album = c.getString(3) ?: ""
                        arr.put(JSONObject().apply {
                            put("id", c.getLong(0))
                            put("name", c.getString(1) ?: "audio")
                            put("artist", if (artist == "<unknown>") "" else artist)
                            put("album", if (album == "<unknown>") "" else album)
                            put("size", c.getLong(4))
                            put("mime", c.getString(5) ?: "audio/mpeg")
                            put("added", c.getLong(6) * 1000)
                        })
                    }
                }
            } catch (_: Exception) {
            }
            return arr.toString()
        }
    }

    /** Serves a MediaStore audio file to the WebView, with HTTP Range support for seeking. */
    private fun serveMedia(request: WebResourceRequest): WebResourceResponse {
        val notFound = WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
        if (!hasAudioPermission()) return notFound
        val id = request.url.lastPathSegment?.toLongOrNull() ?: return notFound
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        return try {
            val afd = contentResolver.openAssetFileDescriptor(uri, "r") ?: return notFound
            val total = afd.length
            val mime = contentResolver.getType(uri) ?: "audio/mpeg"
            val stream = afd.createInputStream()
            val range = request.requestHeaders?.entries
                ?.firstOrNull { it.key.equals("Range", true) }?.value

            if (total <= 0) {
                val h = hashMapOf("Accept-Ranges" to "none")
                return WebResourceResponse(mime, null, 200, "OK", h, stream)
            }

            var start = 0L
            var end = total - 1
            var partial = false
            if (range != null && range.startsWith("bytes=")) {
                val parts = range.removePrefix("bytes=").split("-")
                val s = parts.getOrNull(0)?.toLongOrNull()
                val e = parts.getOrNull(1)?.toLongOrNull()
                if (s != null) {
                    start = s
                    if (e != null) end = minOf(e, total - 1)
                } else if (e != null) {
                    start = maxOf(0L, total - e)
                }
                partial = true
            }
            if (start >= total) {
                stream.close()
                val h = hashMapOf("Content-Range" to "bytes */$total")
                return WebResourceResponse(mime, null, 416, "Range Not Satisfiable", h, ByteArrayInputStream(ByteArray(0)))
            }
            var skipped = 0L
            while (skipped < start) {
                val n = stream.skip(start - skipped)
                if (n <= 0) break
                skipped += n
            }
            val length = end - start + 1
            val headers = hashMapOf(
                "Accept-Ranges" to "bytes",
                "Content-Length" to length.toString(),
                "Access-Control-Allow-Origin" to "*"
            )
            if (partial) headers["Content-Range"] = "bytes $start-$end/$total"
            WebResourceResponse(
                mime, null,
                if (partial) 206 else 200,
                if (partial) "Partial Content" else "OK",
                headers, BoundedStream(stream, length)
            )
        } catch (e: Exception) {
            notFound
        }
    }

    private class BoundedStream(input: InputStream, private var left: Long) : FilterInputStream(input) {
        override fun read(): Int {
            if (left <= 0) return -1
            val b = super.read()
            if (b >= 0) left--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val n = super.read(b, off, minOf(len.toLong(), left).toInt())
            if (n > 0) left -= n
            return n
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        webView.evaluateJavascript("window.onNativeAudioPermission && window.onNativeAudioPermission()", null)
    }

    private fun startPlayService() {
        try {
            val i = Intent(this, PlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (_: Exception) {
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_FILES) {
            var result: Array<Uri>? = null
            if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                result = if (clip != null) {
                    Array(clip.itemCount) { clip.getItemAt(it).uri }
                } else {
                    data.data?.let { arrayOf(it) }
                }
            }
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    // Keep music playing in the background: do NOT pause the WebView.
    override fun onPause() {
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        ui.removeCallbacks(ticker)
        releaseVlc()
        exo?.release()
        exo = null
        if (isFinishing) stopService(Intent(this, PlayService::class.java))
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val REQ_FILES = 100
    }
}
