plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.faudio.player"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.faudio.player.lite"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "1.1-ffmpeg"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
    val media3 = "1.11.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-extractor:$media3")
    implementation("androidx.media3:media3-decoder:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-datasource:$media3")
    // FFmpeg software decoders (ALAC, AC3, EAC3, TrueHD, DTS, FLAC, Opus, etc.)
    implementation("io.github.anilbeesetti:nextlib-media3ext:1.11.1-0.18.0")
}
