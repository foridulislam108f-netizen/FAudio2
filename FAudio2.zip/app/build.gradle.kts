plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.faudio.player"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.faudio.player.lite"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    // Extractors add container support; codec availability still depends on
    // Media3 and the device decoder implementations.
    implementation("androidx.media3:media3-extractor:1.4.1")
    implementation("androidx.media3:media3-decoder:1.4.1")
    // There is no official prebuilt Media3 FFmpeg AAR in this dependency set.
    // Do not claim universal codec support unless a bundled FFmpeg build is
    // added; the app uses the native decoder path as the reliable fallback.
    implementation("androidx.media3:media3-exoplayer-dash:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-datasource:1.4.1")
    // VLC engine: broad demuxer/codec coverage for files that Android/WebView
    // cannot decode reliably, including many M4A/WMA/APE/AC3 variants.
    implementation("org.videolan.android:libvlc-all:3.6.0")
}
