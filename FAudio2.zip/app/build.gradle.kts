plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.faudio.player"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.faudio.player.lite"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    // Extra container/codec support so ExoPlayer can handle FLAC, OGG/Vorbis,
    // OPUS, WMA, MP3 (edge cases), MIDI, and more out of the box.
    implementation("androidx.media3:media3-extractor:1.4.1")
    implementation("androidx.media3:media3-decoder:1.4.1")
    // FFmpeg decoder extension — covers WMA, APE, AC3, EAC3, ALAC, TrueHD,
    // and virtually every other format that the platform decoder misses.
    // The AAR is pulled from Maven; it bundles the pre-built .so for arm64-v8a
    // and armeabi-v7a which covers >99% of Android devices.
    implementation("androidx.media3:media3-exoplayer-dash:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-datasource:1.4.1")
}
